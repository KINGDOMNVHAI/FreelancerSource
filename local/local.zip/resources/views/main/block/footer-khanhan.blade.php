<section class="news-part" style="background: url({{ asset('frontend/images/newsletter.jpg') }}) no-repeat center;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-lg-6 col-xl-7">
                <div class="news-text">
                    <h2>Hãy đến Nhà Thuốc Khánh An ngay hôm nay!</h2>
                    <p>Để được tư vấn và chăm sóc tận tình, chu đáo!</p>
                </div>
            </div>
            {{-- <div class="col-md-7 col-lg-6 col-xl-5">
                <form class="news-form">
                    <input type="text" placeholder="Enter Your Email Address">
                    <button><span><i class="icofont-ui-email"></i>Subscribe</span></button>
                </form>
            </div> --}}
        </div>
    </div>
</section>
<section class="intro-part">
    <div class="container">
        <div class="row intro-content">
            <div class="col-sm-6 col-lg-3">
                <div class="intro-wrap">
                    <div class="intro-icon"><i class="fas fa-truck"></i></div>
                    <div class="intro-content">
                        <h5>Vận chuyển miễn phí</h5>
                        <p>Miễn phí vận chuyển với đơn hàng trên 700.000 VND</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="intro-wrap">
                    <div class="intro-icon"><i class="fas fa-sync-alt"></i></div>
                    <div class="intro-content">
                        <h5>Chính sách hoàn trả</h5>
                        <p>Nếu sản phẩm bị lỗi, quý khách sẽ được đổi trả ngay lập tức.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="intro-wrap">
                    <div class="intro-icon"><i class="fas fa-headset"></i></div>
                    <div class="intro-content">
                        <h5>Hỗ trợ nhanh chóng</h5>
                        <p>Sẵn sàng tư vấn, hỗ trợ qua Zalo và điện thoại.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="intro-wrap">
                    <div class="intro-icon"><i class="fas fa-lock"></i></div>
                    <div class="intro-content">
                        <h5>Bảo mật an toàn</h5>
                        <p>Thông tin của quý khách sẽ được chúng tôi bảo mật an toàn.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<footer class="footer-part">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-xl-4">
                <div class="footer-widget">
                    <center><a class="footer-logo" href="/"><img
                                src="{{ asset('frontend/images/logo-nha-thuoc-khanh-an-3.png') }}"
                                alt="logo nhà thuốc khánh an"></a></center>
                    <p class="footer-desc">Nhà thuốc khánh an, nơi cung cấp siro ăn ngon cho trẻ biếng ăn, mật ong hoa
                        cà phê, hỗ trợ gan, tim mạch... Hãy liên hệ với chúng tôi để được tư vấn miễn phí.</p>
                    {{-- <ul class="footer-social">
                        <li><a class="icofont-facebook" href="#"></a></li>
                        <li><a class="icofont-twitter" href="#"></a></li>
                    </ul> --}}
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="footer-widget contact">
                    <h3 class="footer-title">{{ __('main-home.contact_us') }}</h3>
                    <ul class="footer-contact">
                        <li><i class="icofont-ui-email"></i>
                            <p><span>{{ EMAIL }}</span></p>
                        </li>
                        <li><i class="icofont-ui-touch-phone"></i>
                            <p><span>{{ PHONE_TEXT }}</span></p>
                        </li>
                        <li><i class="icofont-location-pin"></i>
                            <p>{{ ADDRESS }}</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="footer-widget">
                    <h3 class="footer-title">Các liên kết khác</h3>
                    <div class="footer-links">
                        <ul>
                            <li><a href="{{ URL_LAZADA }}" title="Nhà thuốc Khánh An">Lazada</a></li>
                        </ul>
                        <ul>
                            <li><a href="{{ URL_SHOPEE }}" title="Nhà thuốc Khánh An">Shopee</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="footer-bottom">
                    <p class="footer-copytext">&copy; Trang web được thiết kế bởi nhà thuốc Khánh An</p>
                    {{-- <div class="footer-card">
                        <a href="#"><img src="images/payment/jpg/01.jpg" alt="payment"></a>
                        <a href="#"><img src="images/payment/jpg/02.jpg" alt="payment"></a>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="{{ asset('frontend/vendor/bootstrap/jquery-1.12.4.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/bootstrap/popper.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/bootstrap/bootstrap.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/countdown/countdown.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/niceselect/nice-select.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/slickslider/slick.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/venobox/venobox.min.js') }}"></script>
<script src="{{ asset('frontend/js/nice-select.js') }}"></script>
<script src="{{ asset('frontend/js/countdown.js') }}"></script>
<script src="{{ asset('frontend/js/accordion.js') }}"></script>
<script src="{{ asset('frontend/js/venobox.js') }}"></script>
<script src="{{ asset('frontend/js/slick.js') }}"></script>
<script src="{{ asset('frontend/js/main.js') }}"></script>
