@extends('main.master-main')

@section('content-head')
    <link rel="stylesheet" href="{{ asset('frontend/css/home-grid.css') }}">
@endsection

@section('content')

<section class="error-part">
    <div class="container">
        <h1>404 | Not Found</h1>
        <img class="img-fluid" src="{{asset('frontend/images/error.png')}}" alt="error">
        <h3>Ooopps! Không tìm thấy trang.</h3>
        <a href="/">Trở về trang chủ</a>
    </div>
</section>

@endsection
