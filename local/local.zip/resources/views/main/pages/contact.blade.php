@extends('main.master-main')

@section('content-head')
<link rel="stylesheet" href="{{asset('frontend/css/contact.css')}}">
@endsection

@section('content')

<section class="inner-section single-banner" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
    <div class="container">
        <h2>Liên hệ</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="#">Liên hệ</a></li>
        </ol>
    </div>
</section>
<section class="inner-section contact-part">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <div class="contact-card"><i class="icofont-phone"></i>
                    <h4>Số điện thoại</h4>
                    <p><a href="tel:{{PHONE}}">{{PHONE_TEXT}}</a></p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="contact-card"><i class="icofont-email"></i>
                    <h4>Email</h4>
                    <p><a href="mailto:{{EMAIL}}">{{EMAIL}}</a></p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="contact-card"><i class="icofont-location-pin"></i>
                    <h4>Địa chỉ</h4>
                    <p>{{ADDRESS}}</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="contact-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.327815805723!2d106.58496821480077!3d10.786185192314855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x159d08ae897699ac!2zMTDCsDQ3JzEwLjMiTiAxMDbCsDM1JzEzLjgiRQ!5e0!3m2!1svi!2s!4v1658769687281!5m2!1svi!2s" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
