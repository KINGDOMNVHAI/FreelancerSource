@extends('main.master-main')

@section('content-head')
<link rel="stylesheet" href="{{asset('frontend/css/checkout.css')}}">
@endsection

@section('content')

<section class="inner-section single-banner" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
    <div class="container">
        <h2>ĐẶT THÀNH CÔNG</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Trang chủ</a></li>
            <li class="breadcrumb-item active" aria-current="page">Đặt hàng thành công</li>
        </ol>
    </div>
</section>
<section class="inner-section checkout-part">
    <div class="container">
        <div class="row">
            <!-- <div class="col-lg-12">
                <div class="alert-info">
                    <p>Returning customer? <a href="login.html">Click here to login</a></p>
                </div>
            </div> -->
            <div class="col-lg-12">
                <div class="account-card">
                    <div class="account-title">
                        <h4>Đặt hàng thành công</h4>
                    </div>
                    <div class="account-content">
                        <div class="table-scroll">
                            <h2>Email đã được gửi cho bạn</h2>
                        </div>
                        <!-- <div class="chekout-coupon"><button class="coupon-btn">Do you have a coupon code?</button>
                            <form class="coupon-form">
                                <input type="text" placeholder="Enter your coupon code">
                                <button type="submit"><span>apply</span></button>
                            </form>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="contact-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new contact</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option selected>choose title</option>
                        <option value="primary">primary</option>
                        <option value="secondary">secondary</option>
                    </select></div>
                <div class="form-group"><label class="form-label">number</label><input class="form-control"
                        type="text" placeholder="Enter your number"></div><button class="form-btn"
                    type="submit">save contact info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="address-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new address</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option selected>choose title</option>
                        <option value="home">home</option>
                        <option value="office">office</option>
                        <option value="Bussiness">Bussiness</option>
                        <option value="academy">academy</option>
                        <option value="others">others</option>
                    </select></div>
                <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                        placeholder="Enter your address"></textarea></div><button class="form-btn"
                    type="submit">save address info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="payment-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new payment</h3>
                </div>
                <div class="form-group"><label class="form-label">card number</label><input class="form-control"
                        type="text" placeholder="Enter your card number"></div><button class="form-btn"
                    type="submit">save card info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="contact-edit">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>edit contact info</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option value="primary" selected>primary</option>
                        <option value="secondary">secondary</option>
                    </select></div>
                <div class="form-group"><label class="form-label">number</label><input class="form-control"
                        type="text" value="+8801838288389"></div><button class="form-btn" type="submit">save contact
                    info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="address-edit">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>edit address info</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option value="home" selected>home</option>
                        <option value="office">office</option>
                        <option value="Bussiness">Bussiness</option>
                        <option value="academy">academy</option>
                        <option value="others">others</option>
                    </select></div>
                <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                        placeholder="jalkuri, fatullah, narayanganj-1420. word no-09, road no-17/A"></textarea>
                </div><button class="form-btn" type="submit">save address info</button>
            </form>
        </div>
    </div>
</div>

@endsection
