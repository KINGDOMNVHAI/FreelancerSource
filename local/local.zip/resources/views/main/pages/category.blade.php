@extends('main.master-main')

@section('content-head')
<link rel="stylesheet" href="{{asset('frontend/css/home-grid.css')}}">
@endsection

@section('content')

<section class="inner-section single-banner" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
    <div class="container">
        <h2>{{$detailCategory->name_cat}}</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Trang chủ</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{$detailCategory->name_cat}}</li>
        </ol>
    </div>
</section>
<section class="inner-section shop-part">
    <div class="container">
        <div class="row content-reverse">
            <div class="col-lg-3">
                <div class="shop-widget-promo">
                    <a href="#"><img src="{{asset('frontend/images/promo/shop/01.jpg')}}" alt="promo"></a>
                </div>
                {{-- <div class="shop-widget">
                    <h6 class="shop-widget-title">Filter by Price</h6>
                    <form>
                        <div class="shop-widget-group">
                            <input type="text" placeholder="Min - 00">
                            <input type="text" placeholder="Max - 5k">
                        </div>
                        <button class="shop-widget-btn"><i class="fas fa-search"></i><span>search</span></button>
                    </form>
                </div>
                <div class="shop-widget">
                    <h6 class="shop-widget-title">Filter by Rating</h6>
                    <form>
                        <ul class="shop-widget-list">
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="feat1"><label
                                        for="feat1"><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i></label></div><span
                                    class="shop-widget-number">(13)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="feat2"><label
                                        for="feat2"><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i class="fas fa-star"></i></label>
                                </div><span class="shop-widget-number">(28)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="feat3"><label
                                        for="feat3"><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i class="fas fa-star active"></i><i
                                            class="fas fa-star"></i><i class="fas fa-star"></i></label></div><span
                                    class="shop-widget-number">(35)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="feat4"><label
                                        for="feat4"><i class="fas fa-star active"></i><i
                                            class="fas fa-star active"></i><i class="fas fa-star"></i><i
                                            class="fas fa-star"></i><i class="fas fa-star"></i></label></div><span
                                    class="shop-widget-number">(47)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="feat5"><label
                                        for="feat5"><i class="fas fa-star active"></i><i
                                            class="fas fa-star"></i><i class="fas fa-star"></i><i
                                            class="fas fa-star"></i><i class="fas fa-star"></i></label></div><span
                                    class="shop-widget-number">(59)</span>
                            </li>
                        </ul><button class="shop-widget-btn"><i class="far fa-trash-alt"></i><span>clear
                                filter</span></button>
                    </form>
                </div>
                <div class="shop-widget">
                    <h6 class="shop-widget-title">Filter by Tag</h6>
                    <form>
                        <ul class="shop-widget-list">
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="tag1"><label
                                        for="tag1">new items</label></div><span
                                    class="shop-widget-number">(13)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="tag2"><label
                                        for="tag2">sale items</label></div><span
                                    class="shop-widget-number">(28)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="tag3"><label
                                        for="tag3">rating items</label></div><span
                                    class="shop-widget-number">(35)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="tag4"><label
                                        for="tag4">feature items</label></div><span
                                    class="shop-widget-number">(47)</span>
                            </li>
                            <li>
                                <div class="shop-widget-content"><input type="checkbox" id="tag5"><label
                                        for="tag5">discount items</label></div><span
                                    class="shop-widget-number">(59)</span>
                            </li>
                        </ul><button class="shop-widget-btn"><i class="far fa-trash-alt"></i><span>clear
                                filter</span></button>
                    </form>
                </div> --}}
                <div class="shop-widget">
                    <h6 class="shop-widget-title">Tìm sản phẩm theo danh mục</h6>
                    <form action="{{ route ('search-product')}}" method="POST">
                        {{ csrf_field() }}
                        <input class="shop-widget-search" type="text" name="keyword" placeholder="Tìm kiếm...">
                        <ul class="shop-widget-list shop-widget-scroll">
                            @foreach($listCategoriesCount as $category)
                            <li>
                                <div class="shop-widget-content">
                                    <input type="checkbox" id="idCat" name="idCat[]" value="{{$category->id_cat}}"><label for="cate1">{{$category->name_cat}}</label>
                                </div>
                                <span class="shop-widget-number">({{$category->count_product}})</span>
                            </li>
                            @endforeach
                        </ul>
                        <div class="shop-widget-group">
                            <input type="text" id="minPrice" name="minPrice" placeholder="Giá thấp nhất">
                            <input type="text" id="maxPrice" name="maxPrice" placeholder="Giá cao nhất">
                        </div>
                        <button class="shop-widget-btn"><i class="fas fa-search"></i><span>Tìm kiếm</span></button>
                    </form>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="top-filter">
                            {{-- <div class="filter-show">
                                <label class="filter-label">Show :</label>
                                <select class="form-select filter-select">
                                    <option value="1">12</option>
                                    <option value="2">24</option>
                                    <option value="3">36</option>
                                </select>
                            </div>
                            <div class="filter-short">
                                <label class="filter-label">Short by :</label>
                                <select class="form-select filter-select">
                                    <option selected>default</option>
                                    <option value="3">trending</option>
                                    <option value="1">featured</option>
                                    <option value="2">recommend</option>
                                </select>
                            </div> --}}
                        </div>
                    </div>
                </div>
                <div class="row row-cols-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-4">

                    @foreach($productCategory as $product)
                    <div class="col">
                        <div class="product-card">
                            <div class="product-media">
                                {{-- <div class="product-label">
                                    <label class="label-text sale">Giảm 10%</label>
                                </div>
                                <button class="product-wish wish"><i class="fas fa-heart"></i></button> --}}
                                <a class="product-image" href="{{route('detail-product', $product->url_product)}}" title="{{$product->name_product}}">
                                    <img src="{{asset('upload/images/thumbnail/products/' . $product->thumbnail_product)}}" alt="{{$product->name_product}}">
                                </a>
                            </div>
                            <div class="product-content">
                                <h6 class="product-name"><a href="{{route('detail-product', $product->url_product)}}">{{$product->name_product}}</a></h6>
                                <h6 class="product-price">
                                    {{-- <del>$34</del> --}}
                                    <span>{{$product->price_product}} VND<small>/{{$product->unit_product}}</small></span>
                                </h6>
                                {{-- <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>add</span>
                                </button> --}}
                                <div class="product-action">
                                    <button class="action-minus" title="Quantity Minus">
                                        <i class="icofont-minus"></i>
                                    </button>
                                    <input class="action-input" title="Quantity Number" type="text" name="quantity" value="1">
                                    <button class="action-plus" title="Quantity Plus"><i class="icofont-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach

                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="bottom-paginate">
                            <!-- <p class="page-info">Hiển thị $productCategory->count() trên tổng số $productCategory->count() kết quả</p> -->
                            {!! $productCategory->links('pagination::bootstrap-4') !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
