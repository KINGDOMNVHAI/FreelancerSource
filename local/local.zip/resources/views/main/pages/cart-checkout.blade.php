@extends('main.master-main')

@section('content-head')
<link rel="stylesheet" href="{{asset('frontend/css/checkout.css')}}">
@endsection

@section('content')

<section class="inner-section single-banner" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
    <div class="container">
        <h2>ĐẶT HÀNG</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Trang chủ</a></li>
            <li class="breadcrumb-item active" aria-current="page">Đặt hàng</li>
        </ol>
    </div>
</section>
<section class="inner-section checkout-part">
    <div class="container">
        <div class="row">
            <!-- <div class="col-lg-12">
                <div class="alert-info">
                    <p>Returning customer? <a href="login.html">Click here to login</a></p>
                </div>
            </div> -->
            <div class="col-lg-12">
                <div class="account-card">
                    <div class="account-title">
                        <h4>Giỏ hàng</h4>
                    </div>
                    <div class="account-content">
                        <div class="table-scroll">
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">Serial</th>
                                        <th scope="col">Hình ảnh</th>
                                        <th scope="col">Tên</th>
                                        <th scope="col">Giá</th>
                                        <th scope="col">Số lượng</th>
                                        <th scope="col">Tổng giá</th>
                                        <th scope="col">Xóa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($arrayCart != null)
                                    @foreach($arrayCart as $cart)
                                    <tr>
                                        <td class="table-serial">
                                            <h6>{{ $cart['id_product'] }}</h6>
                                        </td>
                                        <td class="table-image"><img src="{{asset('upload/images/thumbnail/products/' . $cart['thumbnail_product'])}}" alt="{{ $cart['name_product'] }}"></td>
                                        <td class="table-name">
                                            <h6>
                                            <a href="{{route('detail-product', $cart['url_product'])}}">{{ $cart['name_product'] }}</a>
                                            </h6>
                                        </td>
                                        <td class="table-price">
                                            <h6>{{$cart['price_product']}} VND<small>/{{$cart['unit_product']}}</small></h6>
                                        </td>
                                        <td class="table-quantity">
                                            <h6>{{ $cart['quantity'] }}</h6>
                                        </td>
                                        <td class="table-brand">
                                            <h6>{{ $cart['price_product'] * $cart['quantity'] }} VND</h6>
                                        </td>
                                        <td class="table-action">
                                            <a class="trash" href="#" title="{{ $cart['name_product'] }}">
                                                <i class="icofont-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @else
                                    <tr>
                                        <td colspan="6" class="table-serial">
                                            Bạn chưa có sản phẩm trong giỏ hàng
                                        </td>
                                    </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        <!-- <div class="chekout-coupon"><button class="coupon-btn">Do you have a coupon code?</button>
                            <form class="coupon-form">
                                <input type="text" placeholder="Enter your coupon code">
                                <button type="submit"><span>apply</span></button>
                            </form>
                        </div> -->
                        @if($arrayCart != null)
                        <br>
                        <div class="checkout-charge">
                            <ul>
                                <!-- <li><span>Sub total</span><span>$267.45</span></li>
                                <li><span>delivery fee</span><span>$10.00</span></li>
                                <li><span>discount</span><span>$00.00</span></li> -->
                                <li>
                                    <span>Tổng tiền <small>(bao gồm VAT)</small></span>: <span>{{$total}} VND</span>
                                </li>
                            </ul>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
            @if($arrayCart != null)
            <form action="{{route('cart-payment')}}" method="POST">
            {{ csrf_field() }}
            <div class="col-lg-12">
                <div class="account-card">
                    <div class="account-title">
                        <h4>Thông tin cá nhân</h4>
                    </div>
                    <div class="account-content">
                        <p class="mb-2">Nhập thông tin cá nhân của bạn</p>
                        <div class="form-group">
                            <div class="form-input-group"><input class="form-control" type="text" name="fullname" placeholder="Họ tên"><i class="icofont-user-alt-3"></i></div>
                        </div>
                        <div class="form-group">
                            <div class="form-input-group"><input class="form-control" type="email" name="email" placeholder="Email"><i class="icofont-email"></i></div>
                        </div>
                        <div class="form-group">
                            <div class="form-input-group"><input class="form-control" type="tel" name="phone" placeholder="Điện thoại"><i class="icofont-book-mark"></i></div>
                        </div>
                        <div class="form-group">
                            <div class="form-input-group"><textarea class="form-control" name="note" placeholder="Ghi chú"></textarea><i class="icofont-paragraph"></i></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="account-card mb-0">
                    <div class="account-title">
                        <h4>Phương thức thanh toán</h4>
                    </div>
                    <div class="account-content">
                        <p class="mb-2">Hãy chọn phương thức thanh toán. Chúng tôi sẽ phản hồi sau khi nhận được tiền.</p>
                        <div class="row">
                            <div class="col-md-6 col-lg-4 alert fade show">
                                <div class="payment-card payment">
                                    <img src="images/payment/png/02.png" alt="payment">
                                    <h4>Nhận tiền khi giao hàng</h4>
                                    <button class="trash icofont-ui-delete" title="Remove This" data-bs-dismiss="alert"></button>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-4 alert fade show">
                                <div class="payment-card payment active">
                                    <img src="{{asset('frontend/images/payment/vcb-logo.png')}}" width="150px" alt="Vietcombank">
                                    <!-- <h4>VCB</h4> -->
                                    <p><span>****</span><span>****</span><span>****</span><sup>1876</sup></p>
                                    <h5>ÁNH</h5>
                                    <!-- <button class="trash icofont-ui-delete" title="Remove This" data-bs-dismiss="alert"></button> -->
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-4 alert fade show">
                                <div class="payment-card payment">
                                    <img src="images/payment/png/03.png" alt="payment">
                                    <h4>MOMO</h4>
                                    <p>0123 4567 8910</p>
                                    <h5>miron mahmud</h5>
                                    <button class="trash icofont-ui-delete" title="Remove This" data-bs-dismiss="alert"></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="checkout-check">
                        <input type="checkbox" id="checkout-check">
                        <label for="checkout-check">By making this purchase you agree to our <a href="#">Terms and Conditions</a>.</label>
                    </div> -->
                    <div class="checkout-proced">
                        <button type="submit" class="form-btn-group">
                            <span>Thanh toán</span>
                        </button>
                    </div>
                </div>
            </div>
            </form>
            @endif
        </div>
    </div>
</section>
<div class="modal fade" id="contact-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new contact</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option selected>choose title</option>
                        <option value="primary">primary</option>
                        <option value="secondary">secondary</option>
                    </select></div>
                <div class="form-group"><label class="form-label">number</label><input class="form-control"
                        type="text" placeholder="Enter your number"></div><button class="form-btn"
                    type="submit">save contact info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="address-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new address</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option selected>choose title</option>
                        <option value="home">home</option>
                        <option value="office">office</option>
                        <option value="Bussiness">Bussiness</option>
                        <option value="academy">academy</option>
                        <option value="others">others</option>
                    </select></div>
                <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                        placeholder="Enter your address"></textarea></div><button class="form-btn"
                    type="submit">save address info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="payment-add">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>add new payment</h3>
                </div>
                <div class="form-group"><label class="form-label">card number</label><input class="form-control"
                        type="text" placeholder="Enter your card number"></div><button class="form-btn"
                    type="submit">save card info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="contact-edit">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>edit contact info</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option value="primary" selected>primary</option>
                        <option value="secondary">secondary</option>
                    </select></div>
                <div class="form-group"><label class="form-label">number</label><input class="form-control"
                        type="text" value="+8801838288389"></div><button class="form-btn" type="submit">save contact
                    info</button>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="address-edit">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                    class="icofont-close"></i></button>
            <form class="modal-form">
                <div class="form-title">
                    <h3>edit address info</h3>
                </div>
                <div class="form-group"><label class="form-label">title</label><select class="form-select">
                        <option value="home" selected>home</option>
                        <option value="office">office</option>
                        <option value="Bussiness">Bussiness</option>
                        <option value="academy">academy</option>
                        <option value="others">others</option>
                    </select></div>
                <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                        placeholder="jalkuri, fatullah, narayanganj-1420. word no-09, road no-17/A"></textarea>
                </div><button class="form-btn" type="submit">save address info</button>
            </form>
        </div>
    </div>
</div>

@endsection
