@extends('main.master-main')

@section('content-head')
<link rel="stylesheet" href="{{asset('frontend/css/product-details.css')}}">
@endsection

@section('content')

<section class="single-banner inner-section" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
    <div class="container">
        <h2>{{$product->name_product}}</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item"><a href="shop-4column.html">{{$product->name_cat}}</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{$product->name_product}}</li>
        </ol>
    </div>
</section>
<section class="inner-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="details-gallery">
                    <div class="details-label-group">
                        <label class="details-label new">new</label>
                        @if($product->result_discount != null)
                        <label class="details-label off">-{{$product->price_discount}}{{$product->type_discount}}</label>
                        @endif
                    </div>
                    <ul class="details-preview">
                        <li><img src="{{asset('upload/images/thumbnail/products/' . $product->thumbnail_product)}}" alt="{{$product->name_product}}" width="70%"></li>
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_1)}}" alt="{{$product->name_product}}" width="70%"></li>
                        @if($product->img_product_2 != null)
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_2)}}" alt="{{$product->name_product}}" width="100%"></li>
                        @endif
                        @if($product->img_product_3 != null)
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_3)}}" alt="{{$product->name_product}}" width="100%"></li>
                        @endif
                    </ul>
                    <ul class="details-thumb">
                        <li><img src="{{asset('upload/images/thumbnail/products/' . $product->thumbnail_product)}}" alt="{{$product->name_product}}" width="100%"></li>
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_1)}}" alt="{{$product->name_product}}" width="100%"></li>
                        @if($product->img_product_2 != null)
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_2)}}" alt="{{$product->name_product}}" width="100%"></li>
                        @endif
                        @if($product->img_product_3 != null)
                        <li><img src="{{asset('upload/images/products/' . $product->img_product_3)}}" alt="{{$product->name_product}}" width="100%"></li>
                        @endif
                    </ul>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="details-content">
                    <h3 class="details-name">{{$product->name_product}}</h3>
                    {{-- <div class="details-meta">
                        <p>SKU:<span>1234567</span></p>
                        <p>BRAND:<a href="#">radhuni</a></p>
                    </div>
                    <div class="details-rating"><i class="active icofont-star"></i><i
                            class="active icofont-star"></i><i class="active icofont-star"></i><i
                            class="active icofont-star"></i><i class="icofont-star"></i><a href="#">(3
                            reviews)</a></div> --}}
                    @if($product->result_discount != null)
                        <h3 class="details-price">
                            <del>{{$product->price_product}} VND</del>
                            <span>{{$product->result_discount}} VND<small>/ {{$product->unit_product}}</small></span>
                        </h3>
                    @else
                        <h3 class="details-price">
                            <span>{{$product->price_product}} VND<small>/ {{$product->unit_product}}</small></span>
                        </h3>
                    @endif
                    <p class="details-desc">
                        {!! $product->present_product !!}
                    </p>
                    {{-- <div class="details-list-group"><label class="details-list-title">tags:</label>
                        <ul class="details-tag-list">
                            <li><a href="#">organic</a></li>
                            <li><a href="#">fruits</a></li>
                            <li><a href="#">chilis</a></li>
                        </ul>
                    </div>
                    <div class="details-list-group"><label class="details-list-title">Share:</label>
                        <ul class="details-share-list">
                            <li><a href="#" class="icofont-facebook" title="Facebook"></a></li>
                        </ul>
                    </div> --}}

                    <div class="details-add-group">
                        <button class="product-add" title="Bỏ vào giỏ hàng">
                            <i class="fas fa-shopping-basket"></i><span>Bỏ vào giỏ hàng</span>
                        </button>
                        <div class="product-action">
                            <button class="action-minus" title="Quantity Minus">
                                <i class="icofont-minus"></i>
                            </button>
                            <input class="action-input" title="Quantity Number" type="text" id="quantity" name="quantity" value="1">
                            <button class="action-plus" title="Quantity Plus">
                                <i class="icofont-plus"></i>
                            </button>
                            <a href="#" onclick="addCart({{$product->id_product}})" class="product-cart">
                                <i class="fas fa-shopping-basket"></i><span>Bỏ vào giỏ hàng</span>
                            </a>
                        </div>
                    </div>

                    <div class="details-action-group">
                        <!-- <a class="details-wish wish" href="#" title="Add Your Wishlist">
                            <i class="icofont-heart"></i><span>add to wish</span>
                        </a> -->

                        <a class="details-compare" href="tel:0914634439">
                            <i class="fa fa-phone"></i><span>Gọi 0914634439</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="inner-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="product-details-frame">
                    <h3 class="frame-title">Thông tin sản phẩm</h3>
                    <div class="tab-descrip">
                        <p>{!! $product->content_product !!}</p>
                    </div>
                </div>
                {{-- <div class="product-details-frame">
                    <h3 class="frame-title">Spacification</h3>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th scope="row">Product code</th>
                                <td>SKU: 101783</td>
                            </tr>
                            <tr>
                                <th scope="row">Weight</th>
                                <td>1kg, 2kg</td>
                            </tr>
                            <tr>
                                <th scope="row">Styles</th>
                                <td>@Girly</td>
                            </tr>
                            <tr>
                                <th scope="row">Properties</th>
                                <td>Short Dress</td>
                            </tr>
                        </tbody>
                    </table>
                </div> --}}
            </div>
        </div>
    </div>
</section>
<section class="inner-section">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section-heading">
                    <h2>related this items</h2>
                </div>
            </div>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5">
            @foreach($listProductRandom as $product)
            <div class="col" style="min-height:500px;">
                <div class="product-card">
                    <div class="product-media">
                        {{-- <div class="product-label">
                            <label class="label-text sale">Giảm 10%</label>
                        </div>
                        <button class="product-wish wish"><i class="fas fa-heart"></i></button> --}}
                        <a class="product-image" href="{{route('detail-product', $product->url_product)}}" title="{{$product->name_product}}">
                            <img src="{{asset('upload/images/thumbnail/products/' . $product->thumbnail_product)}}" alt="{{$product->name_product}}">
                        </a>
                        {{-- <div class="product-widget">
                            <a title="{{$product->name_product}}" href="compare.html" class="fas fa-random"></a>
                            <a title="Product Video" href="https://youtu.be/9xzcVxSBbG8" class="venobox fas fa-play" data-autoplay="true" data-vbtype="video"></a>
                            <a title="Product View" href="#" class="fas fa-eye" data-bs-toggle="modal" data-bs-target="#product-view"></a>
                        </div> --}}
                    </div>
                    <div class="product-content">
                        {{-- <div class="product-rating">
                            <i class="active icofont-star"></i>
                            <i class="active icofont-star"></i>
                            <i class="active icofont-star"></i>
                            <i class="active icofont-star"></i>
                            <i class="icofont-star"></i><a href="">(3)</a>
                        </div> --}}
                        <h6 class="product-name"><a href="{{route('detail-product', $product->url_product)}}">{{$product->name_product}}</a></h6>
                        <h6 class="product-price">
                            {{-- <del>$34</del> --}}
                            <span>{{$product->price_product}} VND<small>/{{$product->unit_product}}</small></span>
                        </h6>
                        {{-- <button class="product-add" title="Add to Cart">
                            <i class="fas fa-shopping-basket"></i><span>add</span>
                        </button> --}}
                        <div class="product-action">
                            <button class="action-minus" title="Quantity Minus">
                                <i class="icofont-minus"></i>
                            </button>
                            <input class="action-input" title="Quantity Number" type="text" name="quantity" value="1">
                            <button class="action-plus" title="Quantity Plus"><i class="icofont-plus"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        {{-- <div class="row">
            <div class="col-lg-12">
                <div class="section-btn-25"><a href="shop-4column.html" class="btn btn-outline"><i
                            class="fas fa-eye"></i><span>view all related</span></a></div>
            </div>
        </div> --}}
    </div>
</section>

<script>
    function addCart(id) {
        let quantity = Number(document.getElementById('quantity').value);
        window.open("/nhathuoc/cart-add/" + id + "/" + quantity);
    }
</script>

@endsection
