<!doctype html>
<html>
<head>
    @include('auth.block.header')
</head>
<body>
    @yield('content')

    @include('auth.block.footer')
</body>
</html>
