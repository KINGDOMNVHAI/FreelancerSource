<div class="custom-modal modal fade mt-300" id="modalInquiryComplete" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content modal-content-complete text-center">
            <div class="wrap-modal-complete">
                <div class="icon-complete"></div>
                <div class="fs-16 color-373737">Your inquiry has been submitted.</div>
            </div>
        </div>
    </div>
</div>
<script src="{{asset('auth-hanatour/js/slick/slick.min.js')}}"></script>

@yield('content-footer')
