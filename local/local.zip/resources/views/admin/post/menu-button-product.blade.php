<button class="btn" onclick="window.location = '/san-pham/tao-san-pham';">Thêm sản phẩm<div class="ripple-container"></div></button>
<button class="btn btn-primary" onclick="window.location = '/gian-hang/danh-sach-gian-hang';">Gian hàng của bạn</button>
<button class="btn btn-info" onclick="window.location = '/san-pham/danh-sach-san-pham-da-xoa';">Sản phẩm đã xóa</button>
<!-- <button class="btn btn-success">Success</button>
<button class="btn btn-warning">Warning</button>
<button class="btn btn-danger">Danger</button> -->
