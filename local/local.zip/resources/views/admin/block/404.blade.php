@extends("admin.index")
@section("content")
<div class="content">
<img src="{{asset('upload/images/no-thumb/404-error.jpg')}}" width="100%" />
</section>
@stop
