<?php
namespace App\Services\Admin;

use App\Models\posts;
use DB;
use Illuminate\Support\ServiceProvider;

class DashboardService extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     *
     */
    public function analyticsPost()
    {
        $query =  posts::select(
                'categories.id_cat',
                'categories.name_cat AS name_cat_post',
                'categories.url_cat' ,
                DB::raw('count(posts.id_cat_post) as count_post'),
                DB::raw('sum(posts.views) as view_post')
            )
            ->leftJoin('categories','posts.id_cat_post','categories.id_cat')
            ->groupBy('categories.id_cat', 'categories.name_cat', 'categories.url_cat', 'posts.id_cat_post')
            ->orderBy('posts.id_cat_post', 'ASC')
            ->get();

        return $query;
    }
}
