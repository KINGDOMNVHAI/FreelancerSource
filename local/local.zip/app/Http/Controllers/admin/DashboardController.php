<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\All\VideoService;
use App\Services\Admin\DashboardService;
use Illuminate\Support\Facades\Auth;
use App\Services\PostService;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware("auth");
    }

    public function index()
    {
        if (Auth::check())
        {
            $title = config('title.dashboard');
            $dashboardService = new DashboardService;
            $viewDashboard    = $dashboardService->analyticsPost();

            $postService = new PostService;
            $viewNewest = $postService->getListPost(config('limit.6'), false);

            return view('admin.pages.dashboard', [
                'title'         => $title,
                'categories'    => $viewDashboard,
                // 'newest'        => $viewNewest,
            ]);
        }
        else {
            return redirect()->route('login');
        }
    }
}
